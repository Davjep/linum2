#!/bin/bash

curl -s 'wttr.in/Luleå' > /home/davjep/weather.txt