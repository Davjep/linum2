#!/bin/bash

echo "Varje timme: $(date)" >> ~/crondateoutput
exit 0