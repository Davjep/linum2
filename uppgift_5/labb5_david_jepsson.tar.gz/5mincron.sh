#!/bin/bash

echo "Var 5:e min: $(date)" >> ~/crondateoutput
exit 0